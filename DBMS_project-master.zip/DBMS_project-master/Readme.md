Use following command to start the server then click on the link in the terminal

```
cd cab
.\env\Scripts\activate.bat
python3 manage.py runserver
```